# CREATE & EARN — Version 1 Test Setup

This version keeps the existing CREATE & EARN screens and AI tools, and adds a real Supabase authentication foundation.

## 1. Upload this project

Upload this ZIP as a **new/separate project** in Google AI Studio. Do not replace your original working project yet.

## 2. Create a Supabase project

Create a Supabase project, then open **SQL Editor** and run:

`supabase/schema.sql`

This creates the `profiles` table, enables Row Level Security, and creates a profile automatically when a new Auth user is created.

## 3. Add the two Supabase app secrets

In the AI Studio project, add:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`

Use the values from your Supabase project's Connect/API settings.

Do **not** put a Supabase service-role key in the browser or in this ZIP.

Keep your existing `GEMINI_API_KEY` secret for the AI generators.

## 4. Test

1. Open CREATE & EARN.
2. Tap **Get Started**.
3. Choose **Creator** or **Business**.
4. Create an account with email + password.
5. Confirm the email if your Supabase Auth settings require confirmation.
6. Sign in.
7. Confirm that the existing Home/Create/AI screens still open.
8. Use the new logout button in the top bar and sign in again.

## Important

The displayed earnings, opportunities, projects, and other marketplace data are still the original prototype/demo data in this Version 1. They are not real financial records.

Real user-owned projects, opportunities, applications, messaging, earnings, payments, withdrawals, and admin permissions will be connected in later versions.
