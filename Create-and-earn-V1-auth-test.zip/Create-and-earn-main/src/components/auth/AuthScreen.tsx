import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, BriefcaseBusiness, Check, Crown, Eye, EyeOff, Sparkles, UserRound, Zap } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import type { Role } from '../../types';

interface AuthScreenProps {
  mode: 'signup' | 'login';
  onModeChange: (mode: 'signup' | 'login') => void;
  onAuthenticated: (role: Role) => void;
  onBack: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  mode,
  onModeChange,
  onAuthenticated,
  onBack,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'creator' | 'business'>('creator');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setMessage('');

    if (!isSupabaseConfigured || !supabase) {
      setMessage('Connect Supabase first: add VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY to your app secrets.');
      return;
    }

    if (password.length < 6) {
      setMessage('Password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            data: { full_name: name.trim(), role },
          },
        });
        if (error) throw error;

        if (data.session) {
          onAuthenticated(role);
        } else {
          setMessage('Account created. Check your email to confirm your account, then log in.');
          onModeChange('login');
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (error) throw error;

        const savedRole = data.user?.user_metadata?.role;
        onAuthenticated(savedRole === 'business' ? 'business' : 'creator');
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Authentication failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 min-h-full bg-gradient-to-b from-[#0B0E14] via-[#111722] to-[#0B0E14] p-6 text-white overflow-y-auto">
      <button onClick={onBack} className="flex items-center gap-2 text-gray-400 hover:text-white text-sm mb-8">
        <ArrowLeft className="w-4 h-4" /> Back
      </button>

      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#FFB800] via-amber-400 to-yellow-200 flex items-center justify-center">
          <Crown className="w-7 h-7 text-black fill-black" />
        </div>
        <div>
          <h1 className="text-2xl font-black tracking-tight">CREATE <span className="text-[#FFB800]">&</span> EARN</h1>
          <p className="text-xs text-gray-400">Create. Connect. Earn.</p>
        </div>
      </div>

      <div className="mb-7">
        <div className="flex items-center gap-2 text-[#FFB800] text-xs font-bold uppercase tracking-wider">
          <Sparkles className="w-4 h-4" /> {mode === 'signup' ? 'Create your account' : 'Welcome back'}
        </div>
        <h2 className="text-3xl font-black mt-2">{mode === 'signup' ? 'Start building your future.' : 'Sign in to CREATE & EARN.'}</h2>
        <p className="text-gray-400 text-sm mt-2">
          {mode === 'signup' ? 'Your account will become the foundation for your creator or business profile.' : 'Your session is securely managed by Supabase Auth.'}
        </p>
      </div>

      <form onSubmit={submit} className="space-y-4">
        {mode === 'signup' && (
          <>
            <label className="block">
              <span className="text-xs font-bold text-gray-300">Full name</span>
              <input value={name} onChange={(e) => setName(e.target.value)} required
                className="mt-1.5 w-full rounded-2xl bg-[#141A27] border border-[#28344A] px-4 py-3.5 outline-none focus:border-[#FFB800] text-white"
                placeholder="Your name" />
            </label>

            <div>
              <span className="text-xs font-bold text-gray-300">I am joining as</span>
              <div className="grid grid-cols-2 gap-3 mt-1.5">
                <button type="button" onClick={() => setRole('creator')}
                  className={`rounded-2xl border p-4 text-left ${role === 'creator' ? 'border-[#FFB800] bg-[#FFB800]/10' : 'border-[#28344A] bg-[#141A27]'}`}>
                  <UserRound className={`w-5 h-5 ${role === 'creator' ? 'text-[#FFB800]' : 'text-gray-400'}`} />
                  <p className="font-bold mt-2">Creator</p>
                  <p className="text-[11px] text-gray-400 mt-1">Make content & find work</p>
                  {role === 'creator' && <Check className="w-4 h-4 text-[#FFB800] mt-2" />}
                </button>
                <button type="button" onClick={() => setRole('business')}
                  className={`rounded-2xl border p-4 text-left ${role === 'business' ? 'border-[#FFB800] bg-[#FFB800]/10' : 'border-[#28344A] bg-[#141A27]'}`}>
                  <BriefcaseBusiness className={`w-5 h-5 ${role === 'business' ? 'text-[#FFB800]' : 'text-gray-400'}`} />
                  <p className="font-bold mt-2">Business</p>
                  <p className="text-[11px] text-gray-400 mt-1">Post campaigns & hire</p>
                  {role === 'business' && <Check className="w-4 h-4 text-[#FFB800] mt-2" />}
                </button>
              </div>
            </div>
          </>
        )}

        <label className="block">
          <span className="text-xs font-bold text-gray-300">Email</span>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
            className="mt-1.5 w-full rounded-2xl bg-[#141A27] border border-[#28344A] px-4 py-3.5 outline-none focus:border-[#FFB800] text-white"
            placeholder="you@example.com" autoComplete="email" />
        </label>

        <label className="block">
          <span className="text-xs font-bold text-gray-300">Password</span>
          <div className="relative mt-1.5">
            <input type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} required
              className="w-full rounded-2xl bg-[#141A27] border border-[#28344A] px-4 py-3.5 pr-12 outline-none focus:border-[#FFB800] text-white"
              placeholder="At least 6 characters" autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} />
            <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
        </label>

        {message && (
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
            {message}
          </div>
        )}

        <button disabled={loading} type="submit"
          className="w-full py-4 rounded-2xl bg-[#FFB800] text-black font-extrabold flex items-center justify-center gap-2 disabled:opacity-60">
          {loading ? 'Please wait…' : mode === 'signup' ? 'Create Account' : 'Sign In'}
          {!loading && <ArrowRight className="w-5 h-5" />}
        </button>
      </form>

      <div className="mt-6 text-center">
        <button onClick={() => { setMessage(''); onModeChange(mode === 'signup' ? 'login' : 'signup'); }}
          className="text-sm text-gray-400 hover:text-white">
          {mode === 'signup' ? 'Already have an account? ' : 'New to CREATE & EARN? '}
          <span className="text-[#FFB800] font-bold">{mode === 'signup' ? 'Sign in' : 'Create account'}</span>
        </button>
      </div>

      <div className="mt-8 rounded-2xl bg-[#101621] border border-[#202C40] p-4">
        <div className="flex items-center gap-2 text-sm font-bold"><Zap className="w-4 h-4 text-[#FFB800]" /> Real account foundation</div>
        <p className="text-[11px] text-gray-500 mt-1">No fake balance or fake withdrawal is created by this authentication screen.</p>
      </div>
    </div>
  );
};
